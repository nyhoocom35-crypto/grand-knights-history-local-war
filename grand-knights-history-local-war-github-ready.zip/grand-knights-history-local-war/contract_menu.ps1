﻿$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$root = $PSScriptRoot
$script:status = $null
$script:waiting = $false
$form = New-Object System.Windows.Forms.Form
$form.Text = '그란 나이츠 히스토리 — 국가 계약 1.0.0'
$form.ClientSize = New-Object System.Drawing.Size(630,430)
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false
$form.Font = New-Object System.Drawing.Font('Malgun Gothic',10)
$info = New-Object System.Windows.Forms.Label
$info.Location = New-Object System.Drawing.Point(18,16)
$info.Size = New-Object System.Drawing.Size(590,68)
$info.Text = '서버를 켜고 게임에서 한 번 재접속하세요.'
$form.Controls.Add($info)
$nation = New-Object System.Windows.Forms.ComboBox
$nation.Location = New-Object System.Drawing.Point(20,94)
$nation.Size = New-Object System.Drawing.Size(580,28)
$nation.DropDownStyle = 'DropDownList'
$form.Controls.Add($nation)
$periodLabel = New-Object System.Windows.Forms.Label
$periodLabel.Location = New-Object System.Drawing.Point(20,141)
$periodLabel.Size = New-Object System.Drawing.Size(285,25)
$periodLabel.Text = '계약 기간: 전쟁 횟수 (현재 전쟁 포함)'
$form.Controls.Add($periodLabel)
$period = New-Object System.Windows.Forms.NumericUpDown
$period.Location = New-Object System.Drawing.Point(330,139)
$period.Size = New-Object System.Drawing.Size(100,28)
$period.Minimum = 1
$period.Maximum = 60
$period.Value = 3
$form.Controls.Add($period)
$quote = New-Object System.Windows.Forms.Label
$quote.Location = New-Object System.Drawing.Point(20,184)
$quote.Size = New-Object System.Drawing.Size(590,32)
$form.Controls.Add($quote)
$sign = New-Object System.Windows.Forms.Button
$sign.Location = New-Object System.Drawing.Point(20,231)
$sign.Size = New-Object System.Drawing.Size(235,39)
$sign.Text = '이 국가와 계약하기'
$form.Controls.Add($sign)
$refresh = New-Object System.Windows.Forms.Button
$refresh.Location = New-Object System.Drawing.Point(275,231)
$refresh.Size = New-Object System.Drawing.Size(145,39)
$refresh.Text = '상태 새로고침'
$form.Controls.Add($refresh)
$message = New-Object System.Windows.Forms.Label
$message.Location = New-Object System.Drawing.Point(20,285)
$message.Size = New-Object System.Drawing.Size(590,66)
$form.Controls.Add($message)
$notes = New-Object System.Windows.Forms.Label
$notes.Location = New-Object System.Drawing.Point(20,355)
$notes.Size = New-Object System.Drawing.Size(590,66)
$notes.Text = "계약 후 게임에서 재접속하면 국가와 계약금이 적용됩니다.`r`n그 뒤 한 번 더 재접속하여 지급 확인을 받고 게임을 저장하세요.`r`n확인 전에는 상점 이용·전투를 하지 마세요. 만료 후 새 계약이 가능합니다."
$notes.ForeColor = [System.Drawing.Color]::DarkSlateGray
$form.Controls.Add($notes)
$names = @('유니온','로그리스','아발론')
function Update-Quote {
 if ($null -eq $script:status -or $nation.SelectedIndex -lt 0) { return }
 $total = [int]$script:status.rates[$nation.SelectedIndex] * [int]$period.Value
 $quote.Text = ('예상 선불 계약금: {0:N0} G  ({1:N0} G × {2}회)' -f $total,$script:status.rates[$nation.SelectedIndex],$period.Value)
}
function Read-Status {
 $path = Join-Path $root 'contract_status.json'
 if (-not (Test-Path -LiteralPath $path)) {
  $sign.Enabled = $false
  $info.Text = '2_START_SERVER.bat 실행 후 CONTRACT_v12.iso에서 재접속하세요.'
  return
 }
 try { $script:status = Get-Content -LiteralPath $path -Raw | ConvertFrom-Json }
 catch { return } # Atomic writer can briefly replace the file while reading.
 $selected = $nation.SelectedIndex
 if ($selected -lt 0) { $selected = 0 }
 $nation.Items.Clear()
 for ($n=0; $n -lt 3; $n++) {
  [void]$nation.Items.Add(('{0} — 영토 {1}곳 / 회당 {2:N0} G' -f $names[$n],$script:status.territories[$n],$script:status.rates[$n]))
 }
 $nation.SelectedIndex = $selected
 $info.Text = ('캠페인 {0} / 전쟁 {1} · 최근 확인 소지금: {2:N0} G' -f $script:status.war_id,([int]$script:status.round+1),$script:status.money)
 if ($script:status.active) {
  $state = '재접속 대기'
  if ($script:status.started) { $state = '계약 진행 중' }
  $info.Text += ("`r`n{0}: {1} · 남은 전쟁 {2}/{3}회 · 계약금 {4:N0} G" -f $state,$names[$script:status.nation],$script:status.remaining,$script:status.duration,$script:status.amount)
 } elseif ($script:status.duration -gt 0) { $info.Text += "`r`n계약 만료 — 새로운 국가와 기간을 선택할 수 있습니다." }
 $sign.Enabled = (-not $script:status.active) -and ($script:status.money -ge 0)
 $nation.Enabled = -not $script:status.active
 $period.Enabled = -not $script:status.active
 if ($script:status.payment_review) {
  $message.Text = '지급 확인 중 소지금이 달라졌습니다. 중복 지급 방지를 위해 멈췄습니다. 3_EXPORT_LOGS.bat 로그를 보내 주세요.'
  $sign.Enabled = $false
 } elseif ($script:status.payment_confirmed) {
  $message.Text = '계약금 지급 확인 완료. 게임을 저장한 뒤 참전하세요.'
 } elseif ($script:status.started) {
  $message.Text = '국가와 계약금 응답 전송됨. 소지금을 확인하고 한 번 더 재접속하세요.'
 } elseif ($script:status.active) {
  $message.Text = '계약 접수 완료. 게임에서 재접속하세요. 실제 계약금은 위의 확정 금액입니다.'
 } else { $message.Text = [string]$script:status.message }
 Update-Quote
}
$nation.Add_SelectedIndexChanged({ Update-Quote })
$period.Add_ValueChanged({ Update-Quote })
$refresh.Add_Click({ Read-Status })
$sign.Add_Click({
 try {
  if ($null -eq $script:status -or $script:status.active) { return }
  $id = [Guid]::NewGuid().ToString()
  $command = $id + '|' + $nation.SelectedIndex + '|' + [int]$period.Value
  $target = Join-Path $root 'contract_request.txt'
  $temp = Join-Path $root ('contract_request.'+$id+'.tmp')
  [System.IO.File]::WriteAllText($temp,$command,[System.Text.Encoding]::ASCII)
  if ([System.IO.File]::Exists($target)) { [System.IO.File]::Replace($temp,$target,$null) }
  else { [System.IO.File]::Move($temp,$target) }
  $message.Text = '계약 요청 전송됨. 서버가 처리하면 상태가 갱신됩니다.'
  $sign.Enabled = $false
 } catch { [void][System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'계약 오류') }
})
$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 1500
$timer.Add_Tick({ Read-Status })
$form.Add_Shown({ Read-Status; $timer.Start() })
$form.Add_FormClosed({ $timer.Stop(); $timer.Dispose() })
[void]$form.ShowDialog()
$form.Dispose()
