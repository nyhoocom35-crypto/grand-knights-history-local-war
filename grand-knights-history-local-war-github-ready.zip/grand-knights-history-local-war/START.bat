@echo off
setlocal
cd /d "%~dp0"
:menu
cls
echo Grand Knights History - Local War 1.0.0
echo.
echo First install: 1, 2, 3. Then open the patched ISO in PPSSPP.
echo Keep the server window open while playing.
echo.
echo [1] Back up your PPSSPP game save
echo [2] Create the contract-patched ISO
echo [3] Start local war server (separate window)
echo [4] Open nation contract menu
echo [5] Show campaign and AI votes
echo [6] Export diagnostic logs
echo [7] Read Korean installation guide
echo [0] Exit launcher
choice /c 12345670 /n /m "Select: "
if errorlevel 8 exit /b 0
if errorlevel 7 goto guide
if errorlevel 6 goto logs
if errorlevel 5 goto status
if errorlevel 4 goto contract
if errorlevel 3 goto server
if errorlevel 2 goto patch
if errorlevel 1 goto backup
:backup
call "%~dp01_BACKUP_SAVE.bat"
goto menu
:patch
call "%~dp00_PATCH_CONTRACT_ISO.bat"
goto menu
:server
start "" "%~dp02_START_SERVER.bat"
goto menu
:contract
start "" "%~dp06_CONTRACT_MENU.bat"
goto menu
:status
call "%~dp04_SHOW_CAMPAIGN.bat"
goto menu
:logs
call "%~dp03_EXPORT_LOGS.bat"
goto menu
:guide
start "" notepad.exe "%~dp0READ_ME_KO.txt"
goto menu
