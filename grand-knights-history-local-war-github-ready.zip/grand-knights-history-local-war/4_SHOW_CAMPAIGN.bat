@echo off
setlocal
cd /d "%~dp0"
if exist "campaign_status.txt" (notepad.exe "campaign_status.txt") else (echo Start the server and enter online war once to initialize the campaign. & pause)
